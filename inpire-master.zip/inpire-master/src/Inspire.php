<?php

namespace Matrixm\Inspire;

use Illuminate\Support\Facades\Http;

class Inspire {
    public function justDoIt() {
        return "I am custom package";
    }
}